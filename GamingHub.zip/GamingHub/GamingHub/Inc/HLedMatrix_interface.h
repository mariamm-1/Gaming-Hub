#ifndef HLEDMATRIX_INTERFACE_H_
#define HLEDMATRIX_INTERFACE_H_


void HLedMatrix_voidInit();
void HLedMatrix_voidDisplay(u8*Copy_pu8Ptr);
void HLEDMATRIX_voidSlidingText(void);
void HLEDMATRIX_voidBlinkMatrix(u8 times, u32 delayMs);

#endif
